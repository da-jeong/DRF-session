from .models import Memo, Comment
#from users.serializers import UserSerializer
from rest_framework import serializers

class MemoSerializer(serializers.ModelSerializer):
    #author = serializers.ReadOnlyField(source = 'author.nickname')
    class Meta:
        model = Memo
        fields = [
            'title', 'singer', 'date', 'likes',
            'content', 'genre', 'author'
        ]


class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Comment
        fields = ['comment', 'date', 'memo', 'author']